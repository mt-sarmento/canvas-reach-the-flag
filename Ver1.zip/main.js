const canvas = document.getElementById("canvas");
const context = canvas.getContext("2d");
const tileset = new Image();
tileset.src = "tiles\\tile01.png";

canvas.style.border = "3px solid black";

const TILE_SIZE = 16; // tamanho do tile em pixels

const mapa = [
    [1, 0, 0, 1, 1, 1, 1, 4], // delimita tamanho x
    [1, 3, 0, 2, 2, 0, 3, 1],
    [1, 1, 1, 1, 1, 0, 3, 1],
    [4, 4, 4, 1, 1, 0, 0, 2],
    [4, 4, 4, 4, 1, 1, 1, 1]    
];

tileset.onload = () => {
    const colunas = mapa[0].length; // tamanho do mapa em colunas, com base na primeira linha do mapa
    const linhas = mapa.length; // tamanho do mapa em linhas, com base no numero de linhas do mapa

    canvas.width = colunas * TILE_SIZE; // define a largura do canvas com base no número de colunas e o tamanho dos tiles
    canvas.height = linhas * TILE_SIZE; // define a altura do canvas com base no número de linhas e o tamanho dos tiles, ou seja 4 x 16 = 64

    for (let y = 0; y < linhas; y++) { // percorre cada linha do mapa
        for (let x = 0; x < colunas; x++) { // percorre cada coluna do mapa

            const tile = mapa[y][x]; // pega o valor do tile na posição (x, y) do mapa

            const tilesetColuna = tile % (tileset.width / TILE_SIZE);
            const tilesetLinha = Math.floor(tile / (tileset.width / TILE_SIZE)); // descobre a posição do tile dentro do tileset, calculando o

            const rx = tilesetColuna * TILE_SIZE;
            const ry = tilesetLinha * TILE_SIZE; // recorta

            const cx = x * TILE_SIZE;
            const cy = y * TILE_SIZE; // cola

            context.drawImage(
                tileset,              // origem
                rx, ry,               // recorte
                TILE_SIZE, TILE_SIZE, // tamaanho
                cx, cy,               // cola
                TILE_SIZE, TILE_SIZE  // tamanho
            );
        }
    }
};